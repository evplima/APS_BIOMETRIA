Fingerprint filename format: xxx_yyy_zzz.tif
 where xxx is person ID;
       yyy is finger ID;
       zzz is number of scan.
